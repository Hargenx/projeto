import sqlite3

class Database:
    def __init__(self, db):
        try:
            self.conn = sqlite3.connect(db)
            self.cursor = self.conn.cursor()
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS escola(
                                    id_aluno INTEGER PRIMARY KEY AUTOINCREMENT,
                                    nome TEXT,
                                    nota FLOAT)''')
            self.conn.commit()
        except Exception as e:
            print('Erro: na criação da tabela -> ', e)
        
    def ler(self):
        try:
            self.cursor = self.conn.cursor()
            self.cursor.execute('SELECT id_aluno, nome, nota FROM escola')
            item = self.cursor.fetchall()
            for linha in item:
                print(linha)
        except sqlite3.Error as e:
            print(f'Erro: na busca da tabela -> {e}')

    def incluir(self, nome, nota):
        try:
            cursor = self.conn.cursor()
            self.cursor.execute('INSERT INTO escola (nome, nota) VALUES (?, ?)',(nome, nota))
            self.conn.commit()
        except sqlite3.Error as e:
            print(f'Erro: ao incluir na tabela -> {e}')
        finally:
            if cursor:
                cursor.close()

    def remover(self, id_aluno):
        try:
            cursor = self.conn.cursor()
            self.cursor.execute('DELETE FROM escola WHERE id_aluno = ?',(id_aluno, ))
            self.conn.commit()
            self.conn.execute('VACUUM')
        except sqlite3.Error as e:
            print(f'Erro: ao deletar na tabela -> {e}')
        finally:
            if cursor:
                cursor.close()

    def alterar(self, id_aluno, nome, nota):
        try:
            cursor = self.conn.cursor()
            atualizar_query = 'UPDATE escola SET nome = ?, nota = ? WHERE id_aluno = ?'
            dados = (nome, nota, id_aluno)
            self.cursor.execute(atualizar_query, dados)
            self.conn.commit()
        except sqlite3.Error as e:
            print(f'Erro: ao incluir na tabela -> {e}')
        finally:
            if cursor:
                cursor.close()

    def __del__(self):
        if self.conn:
            self.conn.close()

if __name__ == '__main__':
    # Banco de dados local db = Database('Aula_CRUD/tabela.db')
    db = Database(':memory:')
    
    db.incluir('Karl Franz', 8.5)
    db.incluir('ikkit Claw', 8)
    db.incluir('Balthasar Gelt', 9)
    db.incluir('Mannfred Von Carstein', 6)
    db.incluir('Teclis', 10)
    db.incluir('Alarielle', 10)
    db.incluir('Morathi', 7)

    print('Lista:')
    db.ler()

    db.remover(1)
    
    print('\nLista apos remover:')
    db.ler()

    db.alterar(2, 'Malekith', 9)

    db.incluir('Tyrion', 10)

    print('\nLista apos alterar:')
    db.ler()

    db.__del__