def soma_divisor(numero):
    try:
        divisor = [1]
        for i in range(2, numero+1):
            print(i)
            if (numero % i) == 0:
                divisor.append(i)
                print(divisor)
    except IndexError as ie:
        print(f'Erro: {ie}')
    except Exception as e:
        print(f'Erro: {e}')

    return sum(divisor)

#numero = int(input('Digite um valor: '))
#print(soma_divisor(numero))
print(soma_divisor(22))
