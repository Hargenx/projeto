# Para remover caracteres em branco e quebras de linha (\n) do início e do final de uma string,
# devemos utilizar o método:
string = '    Texto\n'
print(string)
print(string.strip())
print(string)