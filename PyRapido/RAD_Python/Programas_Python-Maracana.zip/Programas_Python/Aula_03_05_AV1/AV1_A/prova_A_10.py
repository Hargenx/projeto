# Assinale o código Python que cria um novo arquivo, contendo uma linha.'

f = open('RAD_Python/Aula_03_05_AV1/AV1_A/teste.txt', 'w')
f.write('Linha de teste\n')
f.close()