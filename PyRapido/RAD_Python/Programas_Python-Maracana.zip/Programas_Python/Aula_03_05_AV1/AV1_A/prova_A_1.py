# Considere a imagem a seguir, onde temos um script e um arquivo texto.
# Qual será o resultado impresso pelo script:
with open('RAD_Python/Aula_03_05_AV1/AV1_A/exercicio.txt') as arquivo:
    contador = 0
    for linha in arquivo:
        if linha.strip() and linha.split(':')[1]:
            contador += 1
    print(contador)