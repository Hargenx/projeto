# 3 - No Python 3.7, a instrução que realiza a impressão de uma lista de cadeias de caracteres
# nomeada "y", separando cada elemento com uma vírgula, é:

y = ['Raphael', 'Caroline', 'Vanessa', 'Amanada', 'Gilson', 'Sara', 'Vinicius']
print(', '.join(y))