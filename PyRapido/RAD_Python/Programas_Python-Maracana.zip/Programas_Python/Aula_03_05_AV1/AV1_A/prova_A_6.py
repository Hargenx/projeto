# Considere o código a seguir, onde desejamos renomear o arquivo inicio.txt.
# Analise a exceção exibida na figura e indique qual instrução deve substituir a linha 3, de
# forma a garantir a correta execução do programa.

import os
os.replace("RAD_Python/Aula_03_05_AV1/AV1_A/inicio.txt", "RAD_Python/Aula_03_05_AV1/AV1_A/fim.txt")