# Dentro do nosso dia-a-dia utilizamos try para utilizarmos tratamento para possiveis erros, quando a 
# parte else de tryexcept- else será executada?

try:
    with open('RAD_Python/Aula_03_05_AV1/AV1_B/arquivo.txt', 'r') as arquivo:
        print(arquivo.read())
except FileNotFoundError:
    print('O arquivo não foi encontrado')
else:
    print('O arquivo foi encontrado')