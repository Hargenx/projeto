# Para ler o conteúdo de um arquivo nomeado file e retornar todas as linhas do arquivo como
# elementos de uma lista, devemos executar qual instrução?

with open('RAD_Python/Aula_03_05_AV1/AV1_B/file.txt', 'r') as file:
    print(file.readlines())