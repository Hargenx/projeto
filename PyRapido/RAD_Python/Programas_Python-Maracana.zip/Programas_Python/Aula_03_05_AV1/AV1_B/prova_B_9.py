# Manipular arquivos pode ser uma boa maneira tanto de salvar informações que estão em sua aplicação em um arquivo
# externo como captar informações de um arquivo externo para colocá-las em sua aplicação. Uma forma bem fácil é
# salvar essas informações em um arquivo de texto. Interprete o código a seguir e marque a opção correta:
arquivo = open("RAD_Python/Aula_03_05_AV1/AV1_B/cadastro.txt","a")
NOME = input('Nome: ')
ENDER = input('Endereco: ')
arquivo.write('\n\nNome: ' + NOME + '\nEndereço: ' + ENDER)
arquivo.close()

# O parâmetro "a" do comando open permite fazer inserções de dados ao final do arquivo;