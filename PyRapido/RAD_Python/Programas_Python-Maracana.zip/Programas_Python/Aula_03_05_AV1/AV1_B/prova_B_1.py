# 1. Dentro de um projeto, foi requisitado que você use uma instrução para adcionar um nome digitado pelo usuário,
#  dentre das opções qual seria a melhor escolha?
with open('RAD_Python/Aula_03_05_AV1/AV1_B/arquivo.txt', 'a') as agenda:
    dado = input('Digite o nome: ')
    agenda.write(dado + '\n')