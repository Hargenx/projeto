# Dentro do uso de try - except, podemos sempre utilizar o erro generico, mas sabemos que quanto mais especifico
# melhor, ainda assim temos outras ferramentas, analise o código abaixo:

def lendo_arquivo(arquivo):
    try:
        with open(arquivo, 'w') as arquivos:
            arquivos.write('Python\n')
            arquivos.write('Java')
    except FileNotFoundError as e:
        print(f'O arquivo não foi encontrado {e}')
    
    try:
        txt = open(arquivo)
        print(txt.read())
    except FileNotFoundError as e:
        print(f'O arquivo não foi encontrado {e}')
    finally:
        txt.close()
#O quadrado amarelo preenchido de vermelho deve ser preenchido com qual comando?
if __name__ == '__main__':
    lendo_arquivo('RAD_Python/Aula_03_05_AV1/AV1_B/arquivo.txt')