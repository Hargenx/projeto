# O Python possui uma infinidade de bibliotecas para facilitar o nosso trabalho
# diário, no caso da necessidade de apagar um arquivo txt de nome arquivo,
# podemos usar a biblioteca os, mas para isso além de importar corretamente,
# devemos utilizar qual função?

import os
os.remove('RAD_Python/Aula_03_05_AV1/AV1_B/arquivo.txt')