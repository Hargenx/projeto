import sqlite3 as conector

def data():
    try:
        conn = conector.connect('RAD_Python/Aula_03_05_AV1/Aula/Escola.db')
        cursor = conn.cursor()

        query = '''CREATE TABLE IF NOT EXISTS Aluno(
                    matricula INTEGER NOT NULL,
                    nome TEXT NOT NULL,
                    data_nascimento DATE NOT NULL,
                    ativo BOOLEAN NOT NULL,
                    PRIMARY KEY(matricula)
                    );'''

        cursor.execute(query)
        conn.commit()

    except conn.DatabaseError as err:
        print(f'ERRO: Banco de dados incorreto. -> {err}')
    except conn.NotSupportedError as nse:
        print(f'ERRO: Operação não suportada. -> {nse}')

    finally:
        if conn:
            cursor.close()
            conn.close()