import sqlite3


class Database:
    def __init__(self, db):
        try:
            self.conn = sqlite3.connect(db)
            self.cursor = self.conn.cursor()
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS escola(
                                    id_aluno INTEGER PRIMARY KEY AUTOINCREMENT,
                                    nome TEXT,
                                    nota FLOAT)''')
            self.conn.commit()
        except Exception as e:
            print("Erro na criação da tabela: ", e)

    def insert(self, nome, nota):
        try:
            self.cursor.execute(f"INSERT INTO escola(nome, nota) VALUES('{nome}', {nota})")
            self.conn.commit()
        except Exception as e:
            print("Erro na inserção de dados: ", e)

    def select_um(self):
        try:
            self.cursor.execute("SELECT * FROM escola")
            linhas = self.cursor.fetchone()
            for linha in linhas:
                print(linha)
        except Exception as e:
            print("Erro na consulta de dados: ", e)

    def select_todos(self):
        try:
            self.cursor.execute("SELECT * FROM escola")
            linhas = self.cursor.fetchall()
            for linha in linhas:
                print(linha)
        except Exception as e:
            print("Erro na consulta de dados: ", e)

    def select_cursor(self):
        try:
            self.cursor.execute("SELECT * FROM escola")
            i = 0
            for linha in self.cursor:
                print(linha[i])
                i += 1
        except Exception as e:
            print("Erro na consulta de dados: ", e)

    def pegar_linhas_limitadas(self, tamanho):
        try:
            self.cursor.execute(f"SELECT * FROM escola")
            linhas = self.cursor.fetchmany(tamanho)
            print(f'Pegando um total de {tamanho} linhas')
            for linha in linhas:
                print('ID: ', linha[0], '\nNome: ', linha[1], '\nNota: ', linha[2])
        except Exception as e:
            print("Erro na consulta de dados: ", e)

    def update(self, id_aluno, nome, nota):
        try:
            self.cursor.execute(f"UPDATE escola SET nome='{nome}', nota={nota} WHERE id_aluno={id_aluno}")
            self.conn.commit()
        except Exception as e:
            print("Erro na atualização de dados: ", e)

    def delete(self, id_aluno):
        try:
            self.cursor.execute(f"DELETE FROM escola WHERE id_aluno={id_aluno}")
            self.conn.commit()
        except Exception as e:
            print("Erro na remoção de dados: ", e)

    def close(self):
        self.cursor.close()
        self.conn.close()

