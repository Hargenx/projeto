#6.	Crie um código em Python para deletar um arquivo txt. (1,0 pontos)
import os
arquivo = 'arquivo.txt'
os.remove(arquivo)
