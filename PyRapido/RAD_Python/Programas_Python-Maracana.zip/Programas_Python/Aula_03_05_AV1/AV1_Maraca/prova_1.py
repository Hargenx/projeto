#1.	Um dos aspectos mais importantes deste modelo é
#  garantir que os protótipos desenvolvidos sejam 
# reutilizáveis para o projeto do sistema, ou seja, 
# a ideia não é criar unidades descartáveis. 
# Isso não contradiz o fato de o protótipo ser flexível, 
# o modelo dito é conhecido como? (1,0 pontos)
#A (X) -  iterativo e incremental.
#B (  ) – iterativo.
#C (  ) – Rapid Application Development.
#D (  ) – incremental.
#E (  ) - Joint Application Development.
