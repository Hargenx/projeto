#7.	Criar uma lista de compras em um arquivo (lista.txt) em Python e exiba
#  o seu conteúdo, após exibir o conteúdo, o usuário pode adicionar um novo
#  item nesta lista, e a cada nova adição perguntar ao usuário se deseja 
# repetir o processo. (2,0 pontos)
def exibir():
    with open('lista.txt', 'r') as agenda:
        for linha in agenda:
            print(linha)
with open('lista.txt', 'a') as agenda:
        while True:
            dado = input('Digite o item: ')
            agenda.write(dado + '\n')
            exibir()
            fim = input('Deseja colocar mais item na lista? (S/N): ')
            if fim == 'N':
                break  