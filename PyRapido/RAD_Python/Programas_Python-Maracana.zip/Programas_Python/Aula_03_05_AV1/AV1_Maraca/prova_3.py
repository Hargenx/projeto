# Para escrever os itens de uma lista nomeada minha_lista, 
# em um arquivo nomeado file, devemos executar qual instrução?

minha_lista = ['item1', 'item2', 'item3']
with open('file.txt', 'w') as file:
    file.writelines(minha_lista)