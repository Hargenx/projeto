#2.	O ciclo de vida da RAD foi projetado para direcionar os
#    desenvolvedores na criação de soluções de software que
#    atendam às necessidades dos usuários. Este ciclo de vida
#    trata das atividades que são necessárias para definir o
#    escopo e os requisitos de negócios, além das atividades
#    para projetar, desenvolver e? (1,0 pontos)
#A (X) -  implementar o sistema.
#B (  ) – testar o sistema.
#C (  ) – debugger o sistema.
#D (  ) – gerenciar o sistema.
#E (  ) – prototipar o sistema.
