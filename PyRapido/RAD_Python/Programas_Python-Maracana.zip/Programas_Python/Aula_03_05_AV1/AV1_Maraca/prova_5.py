#5.	Crie um programa em Python que crie um arquivo (lista.txt) que contenha
#  nomes digitados pelo usuário.(2,0 pontos)
with open('lista.txt', 'a') as agenda:
        while True:
            dado = input('Digite o nome(fim para finalizar): ')
            if dado == 'fim':
                break
            agenda.write(dado + '\n')
