import tkinter as tk
janela = tk.Tk()
ola = tk.Label(text="Oi mamãe! 💓 ")
ola.pack()
janela.mainloop()
