print('Oi, mamãe.')
