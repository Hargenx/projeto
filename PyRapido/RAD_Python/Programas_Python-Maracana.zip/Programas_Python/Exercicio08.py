def lendo_arquivo(arquivo):
    with open(arquivo, "w") as arquivos:
        arquivos.write("Python\n")
        arquivos.write("Java")
    txt = open(arquivo)
    print(txt.read())

lendo_arquivo('Arq.txt')
