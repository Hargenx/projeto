import string

def letras_documento(numero):
    try:
        with open("alfabeto.txt", "w") as arquivo:
            alfabeto = string.ascii_uppercase
            letras = [alfabeto[i:i + numero] + "\n" for i in range(0, len(alfabeto), numero)]
            arquivo.writelines(letras)
    except IOError as ioe:
        print(f'Erro: {ioe}')
    
letras_documento(4)
