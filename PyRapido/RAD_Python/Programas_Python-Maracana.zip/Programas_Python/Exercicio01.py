def frequencia_char(frase1):
    frase = frase1
    dicionario = {}
    for n in frase:
        chave = dicionario.keys()
        if n in chave:
            dicionario[n] += 1
        else:
            dicionario[n] = 1
    return dicionario

def tamanho_string(frase2):
    cont = 0
    for _ in frase2:
        cont += 1
    return cont



frase = "estudante.estacio.br"
print(len('Estacio.br'))
print(tamanho_string("Estacio.br"))
print(frequencia_char(frase))
