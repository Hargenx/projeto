#include <stdio.h>
long int imprimeNome(char *nome){
    printf("Nome: %s\n", nome);
    return 0;
}
int main(void){
    char nome[50];
    printf("Digite o nome: ");
    scanf("%s", &nome);
    imprimeNome(nome);
    return 0;
}
