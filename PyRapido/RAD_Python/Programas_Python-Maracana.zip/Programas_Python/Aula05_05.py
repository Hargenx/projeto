import sqlite3

def banco():
    try:
        db = "escola.db"
        conn = sqlite3.connect(db)
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS escola(
                                        id_aluno INTEGER PRIMARY KEY AUTOINCREMENT,
                                        nome TEXT,
                                        av1 FLOAT,
                                        av2 FLOAT
                                        data DATE,
                                        ativo BOOLEAN)''')
        conn.commit()
    except Exception as e:
        print("Erro na criação da tabela: ", e)
