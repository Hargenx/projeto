import sqlite3

def sql_acao(linhas):
    conn = sqlite3.connect('Correcao_Exercicio/Exercicio_bd/Banco_de_vendas.db')
    cursor_obj = conn.cursor()
    sql_query_inserir = 'INSERT INTO vendedores (vendedores_id, nome, cidade, comissão) VALUES (?, ?, ?, ?);'
    cursor_obj.executemany(sql_query_inserir, linhas)
    conn.commit()
    cursor_obj.execute('SELECT * FROM vendedores')
    linhas = cursor_obj.fetchall()
    print('----- Detalhe dos vendedores ------')
    for linha in linhas:
        print(linha)
    

linhas = [(9006, 'Archaon', 'Chaos', 0.50), 
        (9007, 'Kholek Suneater', 'Chaos', 0.45),
        (9008, 'Mannfred Von Castein', 'Sylvania', 0.35)]

sql_acao(linhas)
