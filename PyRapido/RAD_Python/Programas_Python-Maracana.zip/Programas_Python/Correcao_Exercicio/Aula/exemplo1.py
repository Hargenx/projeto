import tkinter as tk

janela = tk.Tk()
ola = tk.Label(text="Olá Mundo!")

ola.pack()

janela.mainloop()