from tkinter import *
def salvar():
    pass
def carregar():
    pass
root = Tk()
root.geometry("200x150")
frame = Frame(root)
frame.pack()
menu_principal=Menu(frame)
menu_principal.add_command(label="Salvar", command=salvar)
menu_principal.add_command(label="Carregar", command=carregar)
menu_principal.add_command(label="Sair", command=root.destroy)
root.config(menu=menu_principal)
root.mainloop()
