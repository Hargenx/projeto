from collections import Counter

def contar_palavras(nome_arq):
    with open(nome_arq) as arquivo:
        return Counter(arquivo.read().split())

print("Numero de palavras no arquivo: ", contar_palavras("palavras.txt"))
# Colocar outra solução.
arquivo = open('palavras.txt')
contagem = dict() # Usando dict() já vindo do Python, um dicionario já automatico.
for linhas in arquivo:
    palavras = linhas.split()
    for palavra in palavras:
        if palavra in contagem:
            contagem[palavra] += 1
        else:
            contagem[palavra] = 1
print("Numero de palavras no arquivo: ", contagem, "📡 ")

