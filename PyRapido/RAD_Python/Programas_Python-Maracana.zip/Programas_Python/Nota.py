msg = 'Oi, mamãe. 😻 '

print(msg)

nome = str(input('Qual o seu nome? '))
av1 = float(input('Digite a sua AV1: '))
av2 = float(input('Digite a sua AV2: '))

media = (av1+av2)/2

print(f'{nome} sua media eh igual: {media}')
print(nome, 'sua media eh igual: ', media)
#Comentario
with open(f'{nome}.txt', 'w') as dados:
    dados.write('linha 1\n')
    dados.write('linha 2')
    linhas = [', Ainda linha 2', '\nlinha 3', '\nlinha 4\n']
    dados.writelines(linhas)
    dados.write('Fim.')
    dados.write('\n')



def nome():
    pass